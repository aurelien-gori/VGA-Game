#include "plasma.h"

#define MemoryRead(A) (*(volatile unsigned int*)(A))
#define MemoryWrite(A,V) *(volatile unsigned int*)(A)=(V)
#define GPIO0_OUT 0x20000030
#define GPIO0_CLEAR 0x20000040
#define GPIO1_OUT 0x20000080
#define GPIO1_CLEAR 0x20000090
#define GPIOA_IN 0x20000050
#define GPIO2_OUT 0x200000A0
#define GPIO2_CLEAR 0x200000B0 
#define GPIO6_OUT		  0x20000120
#define GPIO6_CLEAR       0x20000130
#define GPIO7_OUT		  0x20000140
#define GPIO7_CLEAR       0x20000150
#define GPIO5_OUT		  0x20000100
#define GPIO5_CLEAR       0x20000110


void VGA_SPRITE(int x, int y)
{
    int value;
    //on décale x de sorte à ce que cela corresponde au R1(bit de 10 à 19)
    x = x << 10; 
    //on fusionne x et y 
    value = y | x; 
    MemoryWrite(GPIO2_CLEAR, (~value) & 0xfffff); //clear
    MemoryWrite(GPIO2_OUT, value); //set
}

void VGA_SPRITE2(int x, int y)
{
    int value;
    //on décale x de sorte à ce que cela corresponde au R1(bit de 10 à 19)
    x = x << 10; 
    //on fusionne x et y 
    value = y | x; 
    MemoryWrite(GPIO3_CLEAR, (~value) & 0xfffff); //clear
    MemoryWrite(GPIO3_OUT, value); //set
}

void VGA_SPRITE3(int x, int y)
{
    int value;
    //on décale x de sorte à ce que cela corresponde au R1(bit de 10 à 19)
    x = x << 10; 
    //on fusionne x et y 
    value = y | x; 
    MemoryWrite(GPIO4_CLEAR, (~value) & 0xfffff); //clear
    MemoryWrite(GPIO4_OUT, value); //set
}

void VGA_SPRITE5(int x, int y)
{
    int value;
    //on décale x de sorte à ce que cela corresponde au R1(bit de 10 à 19)
    x = x << 10; 
    //on fusionne x et y 
    value = y | x; 
    MemoryWrite(GPIO5_CLEAR, (~value) & 0xfffff); //clear
    MemoryWrite(GPIO5_OUT, value); //set
}

void VGA_SPRITE6(int x, int y)
{
    int value;
    //on décale x de sorte à ce que cela corresponde au R1(bit de 10 à 19)
    x = x << 10; 
    //on fusionne x et y 
    value = y | x; 
    MemoryWrite(GPIO6_CLEAR, (~value) & 0xfffff); //clear
    MemoryWrite(GPIO6_OUT, value); //set
}
void VGA_SPRITE7(int x, int y)
{
    int value;
    //on décale x de sorte à ce que cela corresponde au R1(bit de 10 à 19)
    x = x << 10; 
    //on fusionne x et y 
    value = y | x; 
    MemoryWrite(GPIO7_CLEAR, (~value) & 0xfffff); //clear
    MemoryWrite(GPIO7_OUT, value); //set
}

void VGA_COLOR(int value) {
//ALIGNEMENT DE LA VARIABLE VALUE PAR DECALAGE A GAUCHE DE X BITS
value=value<<20;
MemoryWrite(GPIO0_CLEAR, (~value) & 0xfff00000); //clear
MemoryWrite(GPIO0_OUT, value); //set
}
void SEG7(char E4, char E3, char E2, char E1) {
//ALIGNEMENT DES PARAMETRES PAR DECALAGE A GAUCHE DE X BITS
int tmp=E4<<16 | E3<<20 | E2<<24 | E1<<28 ;
MemoryWrite(GPIO0_CLEAR, (~tmp) & 0xffff0000); //clear
MemoryWrite(GPIO0_OUT, tmp); //set
}


void SEG7b(char E4, char E3, char E2, char E1) {
//ALIGNEMENT DES PARAMETRES PAR DECALAGE A GAUCHE DE X BITS
int tmp=E4 | E3<<8 | E2<<16 | E1<<24 ;
MemoryWrite(GPIO1_CLEAR, (~tmp) & 0xffffffff); //clear
MemoryWrite(GPIO1_OUT, tmp); //set
}

void Led(int value)
{
 MemoryWrite(GPIO0_CLEAR, (~value) & 0xffff); //clear
 MemoryWrite(GPIO0_OUT, value & 0xffff) ; //Change LEDs
 MemoryRead(GPIOA_IN);
}

int SW(void)
{
    return MemoryRead(GPIOA_IN) & 0xffff;
}

int btnD(void)
{
    return (MemoryRead(GPIOA_IN) >> 16) & 1;
}

int btnU(void)
{
    return (MemoryRead(GPIOA_IN) >> 17) & 1;
}

int btnL(void)
{
    return (MemoryRead(GPIOA_IN) >> 18) & 1;
}

int btnR(void)
{
    return (MemoryRead(GPIOA_IN) >> 19) & 1;
}

int putchar(int value)
{
   while((MemoryRead(IRQ_STATUS) & IRQ_UART_WRITE_AVAILABLE) == 0)
      ;
   MemoryWrite(UART_WRITE, value);
   return 0;
}

int puts(const char *string)
{
   while(*string)
   {
      if(*string == '\n')
         putchar('\r');
      putchar(*string++);
   }
   return 0;
}

void print_hex(unsigned long num)
{
   long i;
   unsigned long j;
   for(i = 28; i >= 0; i -= 4) 
   {
      j = (num >> i) & 0xf;
      if(j < 10) 
         putchar('0' + j);
      else 
         putchar('a' - 10 + j);
   }
}

void OS_InterruptServiceRoutine(unsigned int status)
{
   (void)status;
   putchar('I');
}

int kbhit(void)
{
   return MemoryRead(IRQ_STATUS) & IRQ_UART_READ_AVAILABLE;
}

int getch(void)
{
   while(!kbhit()) ;
   return MemoryRead(UART_READ);
}
