
#define MemoryWrite(A,V) *(volatile unsigned int*)(A)=(V)
#define MemoryRead(A) (*(volatile unsigned int*)(A))

int main(void){
	int i,j;
	while(1){
		for(i =0; i<16; i++){
			SEG7(i,i+1,i+2,i+3);
			for(j=0; j<1000000; j++);
		}
		Led(SW()));
			}
return 1;
}