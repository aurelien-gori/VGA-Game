#define GPIO0_OUT 0x20000030
#define GPIO0_CLEAR 0x20000040
#define MemoryWrite(A,V) *(volatile unsigned int*)(A)=(V)
#define MemoryRead(A) (*(volatile unsigned int*)(A))

int puts(const char* string);

void Led(int value)
{
 MemoryWrite(GPIO0_CLEAR, (~value) & 0xff); //clear
 MemoryWrite(GPIO0_OUT, value); //Change LEDs
}

int main(void){
	int i,j;
	puts("Test Led");
	for (i = 0; i < 55; i++){
		Led(i);
		for(j = 0; j < 100000; j++);
	}

}