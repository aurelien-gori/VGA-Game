
#define MemoryWrite(A,V) *(volatile unsigned int*)(A)=(V)
#define MemoryRead(A) (*(volatile unsigned int*)(A))

int main(void){
	int j;
	
	while(1){
		VGA_COLOR(SW());
		for(j=0; j<1000000; j++);
			}
return 1;
}