
#define MemoryWrite(A,V) *(volatile unsigned int*)(A)=(V)
#define MemoryRead(A) (*(volatile unsigned int*)(A))

int main(void){
	int e1,e2,e3,e4,j;
	e1 = 11;//31;
	e2 = 23;//31; 
	e3 = 23;//16;
	e4 = 22;//16;
	j =0;
	while(1){
		
		SEG7b(e4,e3,e2,e1);	
		for(j=0; j<1000000; j++);
			}
return 1;
}