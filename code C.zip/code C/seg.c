#define GPIO0_OUT 0x20000030
#define GPIO0_CLEAR 0x20000040
#define GPIO1_OUT 0x20000080
#define GPIO1_CLEAR 0x20000090
#define GPIOA_IN 0x20000050

#define MemoryWrite(A,V) *(volatile unsigned int*)(A)=(V)
#define MemoryRead(A) (*(volatile unsigned int*)(A))

void SEG7b(char E4, char E3, char E2, char E1) {
//ALIGNEMENT DES PARAMETRES PAR DECALAGE A GAUCHE DE X BITS
int tmp=E4 | E3<<8 | E2<<16 | E1<<24 ;
MemoryWrite(GPIO1_CLEAR, (~tmp) & 0xffffffff); //clear
MemoryWrite(GPIO1_OUT, tmp); //set
}

int main(void){
	int e1,e2,e3,e4,j;
	e1 = 0;
	e2 = 0; 
	e3 = 0;
	e4 = 0;
	j =0;
	while(1){
		
		SEG7b(e4,e3,e2,e1);	
		e4 = e3;
		e3 = e2;
		e2 = e1;
		e1++;
		if(e1 >31) 
		e1 = 0;
		for(j=0; j<1000000; j++);
			}
return 1;
}