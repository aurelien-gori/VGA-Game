#define GPIO0_OUT 0x20000030
#define GPIO0_CLEAR 0x20000040
#define GPIOA_IN 0x20000050

#define MemoryWrite(A,V) *(volatile unsigned int*)(A)=(V)
#define MemoryRead(A) (*(volatile unsigned int*)(A))

int main(void){
	int i =0;
	int j;
	for (i; i<16; i++){
		Led(i);
	}
			for(j = 0; j < 100000; j++);
	
}

/*
void Led(int value)
{
 MemoryWrite(GPIO0_CLEAR, (~value) & 0xff); //clear
 MemoryWrite(GPIO0_OUT, value); //Change LEDs
 MemoryRead(GPIOA_IN);
}
int SW(void)
{
    return MemoryRead(GPIOA_IN) & 0xff;
}

int btnD(void)
{
    return (MemoryRead(GPIOA_IN) >> 8) & 1;
}

int btnU(void)
{
    return (MemoryRead(GPIOA_IN) >> 9) & 1;
}

int btnL(void)
{
    return (MemoryRead(GPIOA_IN) >> 10) & 1;
}

int btnR(void)
{
    return (MemoryRead(GPIOA_IN) >> 11) & 1;
}

int main(void){
	int i,j;
	puts("Test Led");
	
	while(1){
		Led(((btnR() << 0) + (btnL() << 1) + (btnU() << 2) + (btnD() << 3) + SW()));
		for(j = 0; j < 100000; j++);
	}
	return 1;
}*/