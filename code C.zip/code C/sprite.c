#define MemoryWrite(A,V) *(volatile unsigned int*)(A)=(V)
#define MemoryRead(A) (*(volatile unsigned int*)(A))

// Penser à faire un ecran d'acceuil (afficher l'image et if bouton => tout le code)
// Penser à la gestion des boutons pour avancer (if btn => x = x+545648545)
// Code des collisions de alexis a prendre
// si collision, afficher game over et revenir a ecran d'acceuil
// Si image d'ayoub touche en haut de l'écran, afficher win

int main(void)
{
	// definition des constantes
    int j = 0, k = 0, l = 0, m = 1, n = 1;
	int value = -1;
	int x = 300; 
	int y = 430;
	int dx = 1;
	int dy = 1;
	int jeu = -1;
	int arrivee = 0;
    while (1)
	{
// sortie de l'écran d'accueil en appuyant sur le bouton du bas
	if (btnD())
	{
	 jeu = -jeu;
	}		
// début du jeu 
	if(jeu == 1)
	{
// déplacement du personnage jouable avec les boutons
		SEG7b(16,23,31,31);
		if (btnL())
		{
			if(x > 0){
			x = x - dx;
			}
		}
		if (btnU()){
			if (y > 0){
			y = y - dy;
			}
		}
		if (btnD()){
			if (y < 430){
			y = y + dy;
			}
		}
		if (btnR()){
			if (x < 590){
			x = x + dx;
			}
		}
// affichage des sprites et du fond en couleur  
			VGA_SPRITE(j, k);
			VGA_SPRITE3(x,y);
			VGA_SPRITE2(500,200);
			VGA_SPRITE7(640,480);
			VGA_SPRITE5(640,480);
			
			VGA_COLOR(300);
// temporisation
			for (l = 0; l < 50000; l++)
		
				;
// Screen Saver
			j = j + m;
			k = k + n;
			//value = value + 1;

// collisions entre la voiture et le mur
			if (j > (640 - 240) || j < 1)
			{
				m = -m;
			}
			if (k > (400 - 160) || k < 1)
			{
				n = -n;
			}
		
			if((k+160 > 200) && (k - 100 < 200)){
				if((j + 240 == 500) || (j - 100 == 500)){
					m = -m;
               
				}
			}	
			else if((j + 240 > 500) && (j - 100 < 500)){
				if((k + 160 == 200) || (k - 100 == 200)){
					n = -n;
                }
				}

// collisions entre le personnage et la voiture
			if((y + 50 > k) && (y - 160 < k))
			{
				if((x + 50 == j) || (x - 240 == j)){
				SEG7b(22,23,23,11);
				break;
                
            }
        }
			else if((x + 50 > j) && (x - 240 < j))
			{
				if((y + 50 == k) || (y - 160 == k)){
				SEG7b(22,23,23,11);
				break;
				
                
            }
        }
		
		// collisions entre le personnage et le mur 
		if((y + 50 > 200) && (y - 100 < 200))
		{
            if((x + 50 == 500) || (x - 100 == 500)){
				SEG7b(22,23,23,11);
                break;
            }
        }
        else if((x + 50 > 500) && (x - 100 < 500))
		{
            if((y + 50 == 200) || (y - 100 == 200)){
				SEG7b(22,23,23,11);
                break;
            }
        }
			
					
		}
// Condition de victoire
		if (y == 0)
				{
				arrivee = 1;
				} 
// affichage de l'écran de victoire
			if (arrivee == 1)
				{	
				VGA_SPRITE(640, 480);
				VGA_SPRITE2(640,480);
				VGA_SPRITE3(640,480);
				VGA_SPRITE5(640,480);
				VGA_SPRITE7(200,150);
				VGA_COLOR(3500);
				SEG7b(16,16,31,31);
				while(1){
				Led(0xffff);
				for (l = 0; l < 1000000; l++);
				Led(0);
				for (l = 0; l < 1000000; l++);
				}
				break;
				}
// écran d'accueil		
	else 
	{
		SEG7b(11,28,22,13);
		VGA_SPRITE5(250,200);
		VGA_SPRITE(640, 480);
		VGA_SPRITE2(640,480);
		VGA_SPRITE3(640,480);
		VGA_SPRITE7(640,480);
		VGA_COLOR(3700);
		
	}
	
	
	}
}
